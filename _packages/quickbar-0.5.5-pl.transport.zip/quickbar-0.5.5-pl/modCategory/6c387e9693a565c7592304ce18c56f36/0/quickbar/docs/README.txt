--------------------
Extra: QuickBar
--------------------
Version: 0.5.0
Created: December 14, 2012
Author: JP DeVries <mail@devries.jp>
License: GNU GPLv2 (or later at your option)

If logged into the Manager, adds an Evo style hover bar to the top of your site for quick editing.


Thanks for using QuickBar
JP DeVries	
mail@devries.jp

Find QuickBar on GitHub:
https://github.com/jpdevries/QuickBar/