<div class="quickbar-wrapper">
    <div class="quickbar">
        <ul>
        	<li><a href="[[+mgr_url]]?a=30&id=[[*id]]" target="_blank">Edit Resource</a></li>
			<li><a href="[[+mgr_url]]" target="_blank">Dashboard</a></li>
            <li><a href="[[!createNewLink]]" target="_blank">Create Here</a></li>
			[[-<li class="help"><a href="[[~1? &service=`logout` &scheme=`full`]]" data-href="http://rtfm.modx.com/display/revolution20/An+Overview+of+MODX" target="_blank">Help</a></li>]]
    	</ul>
    </div>
</div>